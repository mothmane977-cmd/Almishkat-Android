package com.almishkat.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF0B1020)
private val Panel = Color(0xFF1B2038)
private val Gold = Color(0xFFD6AA4B)
private val Muted = Color(0xFF9AA0B4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlmishkatApp() }
    }
}

@Composable
fun AlmishkatApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("almishkat_projects", android.content.Context.MODE_PRIVATE) }
    val projects = remember {
        mutableStateListOf<String>().apply {
            addAll(prefs.getStringSet("names", emptySet())?.toList()?.sorted() ?: emptyList())
        }
    }
    var selectedTab by remember { mutableStateOf("المصحف") }
    var reading by remember { mutableStateOf("حفص عن عاصم") }
    var showCreateDialog by remember { mutableStateOf(false) }
    var projectName by remember { mutableStateOf("") }
    var projectReading by remember { mutableStateOf("حفص عن عاصم") }
    var currentProject by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Ink, surface = Panel,
        onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Gold) {
                    listOf("المصحف", "الاستوديو", "المكتبة", "الإعدادات").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab; if (tab != "الاستوديو") currentProject = null },
                            icon = { Text(when(tab) { "المصحف" -> "۞"; "الاستوديو" -> "✦"; "المكتبة" -> "▤"; else -> "⚙" }, fontSize = 20.sp) },
                            label = { Text(tab) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Color(0xFF343044), unselectedTextColor = Muted)
                        )
                    }
                }
            },
            snackbarHost = { SnackbarHost(remember { SnackbarHostState() }) }
        ) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item {
                    Spacer(Modifier.height(18.dp))
                    Text("المِشكاة", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    Text("استوديو القرآن الكريم", color = Muted, fontSize = 15.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }

                if (currentProject != null) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text("مشروعك", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text(currentProject!!, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Text("الرواية: $projectReading", color = Muted)
                                Divider(color = Muted.copy(alpha = .25f))
                                Text("مساحة إعداد التصميم القرآني", color = Color.White, fontSize = 18.sp)
                                Text("تم إنشاء المشروع وحفظ اسمه على هذا الجهاز. ستضاف أدوات النص والخلفيات والصوت والتصدير في مراحل التطوير التالية.", color = Muted)
                                Button(onClick = { currentProject = null; selectedTab = "المكتبة" }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
                                    Text("العودة إلى المكتبة", color = Ink)
                                }
                            }
                        }
                    }
                } else when (selectedTab) {
                    "المكتبة" -> {
                        item { SectionTitle("مكتبتي") }
                        if (projects.isEmpty()) item { EmptyCard("لا توجد مشاريع بعد", "أنشئ مشروعك الأول من زر ابدأ مشروعاً جديداً.") }
                        items(projects) { name ->
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().clickable {
                                currentProject = name; selectedTab = "الاستوديو"
                                projectReading = prefs.getString("reading_$name", "حفص عن عاصم") ?: "حفص عن عاصم"
                            }) {
                                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text(name, color = Color.White, fontWeight = FontWeight.Bold); Text("اضغط لفتح المشروع", color = Muted, fontSize = 12.sp) }
                                    Text("›", color = Gold, fontSize = 28.sp)
                                }
                            }
                        }
                        item { Button(onClick = { showCreateDialog = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("إنشاء مشروع جديد", color = Ink) } }
                    }
                    "الإعدادات" -> {
                        item { SectionTitle("الإعدادات") }
                        item { EmptyCard("إعدادات المشكاة", "تفضيلات التطبيق وإدارة المحتوى ستتوفر هنا تدريجياً.") }
                    }
                    "الاستوديو" -> {
                        item { SectionTitle("الاستوديو") }
                        item { EmptyCard("ابدأ مشروعاً جديداً", "أنشئ مشروعاً ليظهر هنا وفي مكتبتك.") }
                        item { Button(onClick = { showCreateDialog = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("ابدأ مشروعاً جديداً", color = Ink, fontWeight = FontWeight.Bold) } }
                    }
                    else -> {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("مساحة الإبداع", color = Gold, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                                    Spacer(Modifier.height(14.dp))
                                    Box(Modifier.fillMaxWidth().height(230.dp).background(Ink, RoundedCornerShape(18.dp)).border(1.dp, Gold.copy(alpha = .5f), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", color = Color.White, fontSize = 22.sp, textAlign = TextAlign.Center)
                                            Spacer(Modifier.height(12.dp))
                                            Text("معاينة التصميم القرآني", color = Muted, fontSize = 12.sp)
                                        }
                                    }
                                    Spacer(Modifier.height(14.dp))
                                    Button(onClick = { projectName = ""; projectReading = reading; showCreateDialog = true }, colors = ButtonDefaults.buttonColors(containerColor = Gold), modifier = Modifier.fillMaxWidth()) {
                                        Text("ابدأ مشروعاً جديداً", color = Ink, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        item { SectionTitle("الرواية") }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                listOf("حفص عن عاصم", "ورش عن نافع").forEach { option ->
                                    FilterChip(selected = reading == option, onClick = { reading = option }, label = { Text(option) }, modifier = Modifier.weight(1f), colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold.copy(alpha = .18f), selectedLabelColor = Gold))
                                }
                            }
                        }
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("أدوات الاستوديو", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    Spacer(Modifier.height(12.dp))
                                    ToolRow("الخلفيات", "صور، ألوان، وتدرجات")
                                    ToolRow("الخطوط والزخارف", "تنسيق النص والهوية البصرية")
                                    ToolRow("الصوت والتزامن", "إعداد التلاوة ومزامنة الآيات")
                                    ToolRow("التصدير", "إعداد فيديو عمودي بجودة عالية")
                                }
                            }
                        }
                    }
                }
                item { if (notice.isNotEmpty()) Text(notice, color = Gold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
                item { Spacer(Modifier.height(18.dp)) }
            }
        }

        if (showCreateDialog) {
            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                containerColor = Panel,
                title = { Text("إنشاء مشروع جديد", color = Gold, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(value = projectName, onValueChange = { projectName = it }, label = { Text("اسم المشروع") }, singleLine = true)
                        Text("اختر الرواية", color = Color.White, fontWeight = FontWeight.SemiBold)
                        listOf("حفص عن عاصم", "ورش عن نافع").forEach { option ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { projectReading = option }) {
                                RadioButton(selected = projectReading == option, onClick = { projectReading = option }, colors = RadioButtonDefaults.colors(selectedColor = Gold))
                                Text(option, color = Color.White)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val cleanName = projectName.trim()
                        if (cleanName.isNotEmpty()) {
                            if (!projects.contains(cleanName)) projects.add(cleanName)
                            prefs.edit().putStringSet("names", projects.toSet()).putString("reading_$cleanName", projectReading).apply()
                            currentProject = cleanName
                            reading = projectReading
                            selectedTab = "الاستوديو"
                            showCreateDialog = false
                            notice = "تم إنشاء المشروع وحفظه بنجاح"
                        }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("إنشاء المشروع", color = Ink) }
                },
                dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("إلغاء", color = Muted) } }
            )
        }
    }
}

@Composable
private fun EmptyCard(title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(subtitle, color = Muted)
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun ToolRow(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Text("›", color = Gold, fontSize = 26.sp)
    }
}
