package com.almishkat.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF0B1020)
private val Panel = Color(0xFF1B2038)
private val Gold = Color(0xFFD6AA4B)
private val Muted = Color(0xFF9AA0B4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlmishkatApp() }
    }
}

@Composable
fun AlmishkatApp() {
    var selectedTab by remember { mutableStateOf("الاستوديو") }
    var reading by remember { mutableStateOf("حفص عن عاصم") }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Ink, surface = Panel,
        onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Gold) {
                listOf("المصحف", "الاستوديو", "المكتبة", "الإعدادات").forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Text(when(tab) { "المصحف" -> "۞"; "الاستوديو" -> "✦"; "المكتبة" -> "▤"; else -> "⚙" }, fontSize = 20.sp) },
                        label = { Text(tab) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Color(0xFF343044), unselectedTextColor = Muted)
                    )
                }
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item {
                    Spacer(Modifier.height(18.dp))
                    Text("المِشكاة", color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    Text("استوديو القرآن الكريم", color = Muted, fontSize = 15.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("مساحة الإبداع", color = Gold, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(14.dp))
                            Box(Modifier.fillMaxWidth().height(230.dp).background(Ink, RoundedCornerShape(18.dp)).border(1.dp, Gold.copy(alpha = .5f), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", color = Color.White, fontSize = 22.sp, textAlign = TextAlign.Center)
                                    Spacer(Modifier.height(12.dp))
                                    Text("معاينة التصميم القرآني", color = Muted, fontSize = 12.sp)
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Button(onClick = { selectedTab = "الاستوديو" }, colors = ButtonDefaults.buttonColors(containerColor = Gold), modifier = Modifier.fillMaxWidth()) {
                                Text("ابدأ مشروعاً جديداً", color = Ink, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                item { SectionTitle("الرواية") }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        listOf("حفص عن عاصم", "ورش عن نافع").forEach { option ->
                            FilterChip(selected = reading == option, onClick = { reading = option }, label = { Text(option) }, modifier = Modifier.weight(1f), colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold.copy(alpha = .18f), selectedLabelColor = Gold))
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp)) {
                            Text("أدوات الاستوديو", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(Modifier.height(12.dp))
                            ToolRow("الخلفيات", "صور، ألوان، وتدرجات")
                            ToolRow("الخطوط والزخارف", "تنسيق النص والهوية البصرية")
                            ToolRow("الصوت والتزامن", "إعداد التلاوة ومزامنة الآيات")
                            ToolRow("التصدير", "إعداد فيديو عمودي بجودة عالية")
                        }
                    }
                }
                item { Text("الإصدار الأولي 0.1.0 • الرواية المختارة: $reading", color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center); Spacer(Modifier.height(18.dp)) }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun ToolRow(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Text("›", color = Gold, fontSize = 26.sp)
    }
}
